<?php
/*Template Name: Contact*/

//this forces full width layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the single page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

//Add hero image above post/page content

// Create new image size for our hero image
add_image_size( 'hero-image', 1400, 400, TRUE ); // creates a hero image size

// Hook after header area
add_action( 'genesis_after_header', 'hero_image');

function hero_image() {
// If it is a page and has a featured thumbnail, but is not the front page do the following...
	if (has_post_thumbnail() && is_page() ) {
		// Get hero image and save in variable called $background
		$image_desktop = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'hero-image' );
		$image_tablet = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'large' );
		$image_mobile = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'medium' );

		$bgdesktop = $image_desktop[0];
		$bgtablet = $image_tablet[0];
		$bgmobile = $image_mobile[0];

// You can change above-post-hero to any class you want and adjust CSS styles
		$featured_class = 'above-post-hero';

		?>
		<div class='<?php echo $featured_class; ?>'></div>
		<style>
			<?php echo ".$featured_class "; ?> {background-image:url( <?php echo $bgmobile; ?>);height:176px; background-size: cover; }

			@media only screen and (min-width : 480px) {
			<?php echo ".$featured_class "; ?> {background-image:url(<?php echo $bgtablet;?>);height:276px; background-size: cover; }
			}
			@media only screen and (min-width : 992px) {
			<?php echo ".$featured_class "; ?> {background-image:url(<?php echo $bgdesktop;?>);height:400px; background-size: cover; }
			}
		</style>
		<?php
	}
}

remove_action( 'genesis_entry_content', 'genesis_do_post_content' );


add_action('genesis_entry_content', 'contact_area');
function contact_area(){
	echo '<div class="contact-form">';
	echo '<div class="two-thirds first contact-form-style">';
	echo '<script type="text/javascript" src="https://cnm.formstack.com/forms/js.php/contact_cnm_ingenuity"></script><noscript><a href="https://cnm.formstack.com/forms/contact_cnm_ingenuity" title="Online Form">Online Form - Contact CNM Ingenuity</a></noscript><div style="text-align:right; font-size:x-small;"><a href="http://www.formstack.com?utm_source=jsembed&utm_medium=product&utm_campaign=product+branding&fa=h,3091635" title="Powered by Formstack">Powered by Formstack</a></div>';
	echo '</div>';
	echo '<div class="contact-content one-third">';
	echo the_content();
	echo '</div>';
	echo '<div class="clearfix">';
	echo '</div>';
}



//hooks Google Map to the genesis_after_entry hook
add_action('genesis_after_entry', 'google_map');
function google_map() {
	echo '<div class="google-container">';
	echo '<h3 class="locations-title">Our Locations</h3>';
	echo '<div class="google-maps">';

	echo '<div class="map">';
	echo '<h5>Workforce Training Center</h5>';
	echo '<p><a href="tel:5052245200">(505) 224-5200</a></p>';
	echo '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13043.16622260115!2d-106.5829033!3d35.1867475!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa71922a0e474c12c!2sCNM+Workforce+Training+Center!5e0!3m2!1sen!2sus!4v1528409048869" width="350" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>';
	echo '</div>';

	echo '<div class="map">';
	echo '<h5>STEMulus Center</h5>';
	echo '<p><a href="tel:5052244717">(505) 224-4717</a></p>';
	echo '<iframe src = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3264.8292413484146!2d-106.65210518602474!3d35.08599908033734!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87220cb8e1af6179%3A0x2e47686d1e27d1d5!2sCNM+STEMulus+Center!5e0!3m2!1sen!2sus!4v1528304692826" width = "350" height = "250" frameborder = "0" style = "border:0" allowfullscreen ></iframe >';
	echo '</div>';

	echo '<div class=" map">';
	echo '<h5>FUSE Makerspace</h5>';
	echo '<p><a href="tel:5052243721">(505) 224-FUSE</a></p>';
	echo '<iframe src = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3264.8996910453866!2d-106.6473875502029!3d35.0842389802413!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87220b62f65c4797%3A0x19eb253d7b0e8e72!2sFUSE+Makerspace!5e0!3m2!1sen!2sus!4v1528304747142" width = "350" height = "250" frameborder = "0" style = "border:0" allowfullscreen ></iframe >';
	echo '</div>';

	echo '<div class="clearfix"></div>';
	echo '</div>';
	echo '</div>';

}
genesis();
