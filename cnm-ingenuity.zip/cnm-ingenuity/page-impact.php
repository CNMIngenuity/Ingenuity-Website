<?php
/**
 * Template Name: Impact Page
 * Description: Used as a single page template for programs included in the Program Archive Page
 */


//this forces full width layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the single page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

//Function that takes the CF's infographic, infograph_title and infograph_description and echoes them on the page
add_action('genesis_entry_content', 'impact_cf_section');
function impact_cf_section() {
	// Grab the custom fields from the impact page
	// on dev env the page ID = 84, need to change for production
	$impact = get_page_by_title('impact');
	$impact_id = $impact->ID;
	$infograph = get_post_meta($impact_id, 'cnmi_demo_infographic', true);
	$impactTitle = get_post_meta($impact_id, 'infograph_title', true);
	$impactDesc = get_post_meta($impact_id, 'infograph_description', true);
	// Echo them on the page
	echo '<div class="impact-infograph">';
	echo '<div class="one-half first">';
	echo '<img src="' . $infograph . '"></img>';
	echo '</div>';
	echo '<div class="one-half impact-desc">';
	echo '<h3>' . $impactTitle . '</h3>';
	echo '<p>' . $impactDesc . '</p>';
	echo '</div>';
	echo '</div>'; //close infograph div
	echo '<div class="clearfix"> </div>';
}

//Function that displays CPT Success Stories
add_action('genesis_after_entry_content', 'impact_success');
function impact_success() {
	echo '<div class="impact-success">';
//This piece of code is what tells WP that we will look for the category for the Single post we are currently on, and display in the widget similar posts that share that same category.
	$category_main = get_the_category();
	$cat_slug = $category_main[0]->slug;
// echo $cat_slug; // This is just to see if I got the right output--> authors note to himself

//Arguments that you can pass through the function. We are displaying only the CPT 'News'
	$args = array(
		'post_type' => 'Success',
		'posts_per_page' => 4,
		'category_name' => $cat_slug,
		'orderby' => 'date',
	);
//Loop through Custom Post Type in there are posts and if we are currently on a single page.  EDIT is_singular is now empty to show on all singular pages in general
	$loop = new WP_Query($args);
	if($loop->have_posts()):
		while($loop->have_posts()) {
			$loop->the_post();
			//Using current Impact Page category to filter through what will be displayed
			$category_course = get_the_category();
			$cat_slug_course = $category_course[0]->slug;
			//   echo $cat_slug_course; // This is just to see if I got the right output --> authors note to himself

			//This is a conditional that takes every other post in the loop, and flips the contents of the columns.
			if(0 == $loop->current_post % 2) {
				echo '<div class="impact-success-story success-story-a">';
				echo '<div class="one-third first">';
				echo '<p class="success-img">' . get_the_post_thumbnail($post, 'medium') . '</p>';
				echo '</div>';
				echo '<div class="two-thirds">';
				echo the_title('<h4>', '</h4>' );
				echo the_excerpt();
				echo '<p><a class="read-more" href="' . get_the_permalink() . '">Read More &#62;&#62;</a>';
				echo '</div>';
				echo '<div class="clearfix"></div>';
				echo '</div>';
			} else {
				echo '<div class="impact-success-story success-story-b">';
				echo '<div class="one-third right">';
				echo '<p class="success-img">' . get_the_post_thumbnail($post, 'medium') . '</p>';
				echo '</div>';
				echo '<div class="two-thirds first left">';
				echo the_title('<h4>', '</h4>');
				echo the_excerpt();
				echo '<p><a class="read-more" href="' . get_the_permalink() . '">Read More &#62;&#62;</a></p>';
				echo '</div>';
				echo '<div class="clearfix"></div>';
				echo '</div>';
			}
		}

	endif;
	echo '<p><a class="light-link-success" href="' . get_post_type_archive_link('success') . '">Read More Success Stories &#62;&#62;</a></p>';

	echo '</div>';
	echo '<div class="clearfix"></div>';

	wp_reset_postdata();
}

//Widget area for CTA

add_action('genesis_after_entry', 'custom_cta_impact');

function custom_cta_impact() {
	if(is_active_sidebar('impact-cta')){

	genesis_widget_area( 'impact-cta', array(
		'before' => '<div class="widget-area">',
		'after' => '</div>',
		) );
	}
}

//-------------------------------------------------------------------------------------------------------------

//This functions displays the CPT News
add_action('genesis_after_entry', 'impact_news');

function impact_news() {
	$newsArchiveLink = get_post_type_archive_link( 'news' );
	echo '<div class="impact-news"><a href="' . $newsArchiveLink . '"><h3 class="news-title">Latest News</h3></a>';
	echo '<div class="impact-news-container">';
//This piece of code is what tells WP that we will look for the category for the Single post we are currently on, and display in the widget similar posts that share that same category.
	$category_main = get_the_category();
	$cat_slug = $category_main[0]->slug;
// echo $cat_slug; // This is just to see if I got the right output--> authors note to himself

//Arguments that you can pass through the function. We are displaying only the CPT 'News'
	$args = array(
		'post_type' => 'News',
		'posts_per_page' => 3,
		'category_name' => $cat_slug,
		'orderby' => 'date',
	);
//Loop through Custom Post Type in there are posts and if we are currently on a single page.
	$loop = new WP_Query($args);
	if($loop->have_posts() && is_singular('page')):
		while($loop->have_posts()) {
			$loop->the_post();
			//Using current Impact Page category to filter through what will be displayed in loop
			$category_course = get_the_category();
			$cat_slug_course = $category_course[0]->slug;
			//   echo $cat_slug_course; // This is just to see if I got the right output --> authors note to himself
			//What will be displayed physically in the loop
			if(has_post_thumbnail()){
				echo '<div class="entry-content news-card">';
			echo '<a href=' . get_the_permalink() . '">';
			the_post_thumbnail('featured');
			echo '<br /><p>';
			the_time('F jS, Y');
			echo '</p><h6>' . get_the_title() . '</h6>';
			echo '</a>';
			echo '<a class="read-more" href=' . get_the_permalink() . '">Read More &#62;&#62;</a>';
			echo '</div>';
		} else {
				echo '<div class="entry-content news-card">';
				echo '<a href=' . get_the_permalink() . '">';
				echo '<img src="'. get_stylesheet_directory_uri() .'/images/ingenuity-logo-300w.png" alt="CNM Logo" />';
				echo '<br />';
				the_time('F jS, Y');
				echo '<br />';
				echo '<h6>' . get_the_title() . '</h6>';
				echo '</a>';
				echo '<a class="read-more" href=' . get_the_permalink() . '">Read More &#62;&#62;</a>';
				echo '</div>';
			}
		}
	endif;
	echo '</div>';
	echo '<div class="more-news-button">';
	echo '<br><a class="button more-news" href="' . $newsArchiveLink . '">View All News</a>';
	echo '</div>';
	wp_reset_postdata();
	echo '</div>';

}

genesis();