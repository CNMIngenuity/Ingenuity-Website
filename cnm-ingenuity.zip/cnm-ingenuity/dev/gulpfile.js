var gulp = require('gulp');
var cssnano = require('gulp-cssnano');
var uglify = require('gulp-uglify');
var autoprefixer = require('gulp-autoprefixer');
var rename = require('gulp-rename');

//which browsers should autoprefix try to support?
const AUTOPREFIXER_BROWSERS = [
    'ie >= 10',
    'ie_mob >= 10',
    'ff >= 30',
    'chrome >= 34',
    'safari >= 7',
    'opera >= 23',
    'ios >= 7',
    'android >= 4.4',
    'bb >= 10'
  ];

// autoprefix css, minify it, and send it to root of theme
gulp.task('css', function() {
        gulp.src('style.css')
        .pipe(autoprefixer({
            browsers: AUTOPREFIXER_BROWSERS
        }))
        .pipe(cssnano())
        // .pipe(rename({ suffix: '.min' }))
        .pipe(gulp.dest('../'));
});

//minify js and send it to js directory
gulp.task('js', function(){
    gulp.src('partner-slider.js')
    .pipe(uglify())
    .pipe(rename({ suffix: '.min' }))
    .pipe(gulp.dest('../js'));
});