<?php

/**
 * Code for CMB2 Custom Fields
 * Creating Field Metaboxes
 */
// initiate the plugin
add_action('cmb2_admin_init', 'cnmi_register_metabox');
/**
 * Hook in and add metaboxes. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */
function cnmi_register_metabox()
{
    $prefix = 'cnmi_demo_';
    /**
     * CMB2 metaboxes for program cpt custom fields
     */
    $cnmi_program_fields = new_cmb2_box(array(
        'id' => $prefix . 'program_meta',
        'title' => esc_html__('Additional Info', 'cmb2'),
        'object_types' => array('program'), // Post type
        // 'show_on_cb' => 'cnmi_show_if_front_page', // function should return a bool value
         'context'    => 'normal',
        // 'priority'   => 'high',
         'show_names' => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // true to keep the metabox closed by default
        // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
        // 'classes_cb' => 'cnmi_add_some_classes', // Add classes through a callback.
    ));

    $cnmi_program_fields->add_field(array(
        'name' => esc_html__('Hexagon Image', 'cmb2'),
        'desc' => esc_html__('Upload a hexagon image for this CNMI Program', 'cmb2'),
        'id' => 'hexagon-image',
        'type' => 'file',
    ));

    $cnmi_program_fields->add_field(array(
        'name' => esc_html__('Website URL', 'cmb2'),
        'desc' => esc_html__('enter the main website URL for this program', 'cmb2'),
        'id' => $prefix . 'program-site-url',
        'type' => 'text_url',
        'protocols' => array('http', 'https'), // Array of allowed protocols
        'repeatable' => false,
    ));
    $cnmi_program_fields->add_field(array(
        'name' => esc_html__('Course Signup URL', 'cmb2'),
        'desc' => esc_html__('enter a course signup link if available', 'cmb2'),
        'id' => $prefix . 'url',
        'type' => 'text_url',
        'protocols' => array('http', 'https'), // Array of allowed protocols
        'repeatable' => false,
    ));

    $cnmi_program_fields->add_field(array(
        'name' => esc_html__('Logo', 'cmb2'),
        'desc' => esc_html__('Upload an image or enter a URL to display the logo of this program', 'cmb2'),
        'id' => $prefix . 'image',
        'type' => 'file',
    ));

    $testimonial_group = $cnmi_program_fields->add_field( array(
        'id'          => 'testimonial_group',
        'type'        => 'group',
        'repeatable'  => true,
        'options'     => array(
            'group_title'   => 'Testimonial {#}',
            'add_button'    => 'Add Another Testimonial',
            'remove_button' => 'Remove Testimonial',
            'sortable'      => true,  // Allow changing the order of repeated groups.
        ),
    ) );

    $cnmi_program_fields->add_group_field($testimonial_group, array(
        'name' => 'Testimonial Quote',
        'desc' => 'a quote that will be displayed on the program page',
        'default' => '',
        'id' => 'testimonial_quote',
        'type' => 'textarea_small',
    ));

    $cnmi_program_fields->add_group_field($testimonial_group, array(
        'name' => 'Quote Author',
        'desc' => 'attribution for the quote entered above, if applicable',
        'default' => '',
        'id' => 'testimonial_quote_author',
        'type' => 'text',
    ));

    $cnmi_program_fields->add_group_field($testimonial_group, array(
        'name' => 'Author Title',
        'desc' => 'Does the quote author above have a title you want displayed? If so, put it here!',
        'default' => '',
        'id' => 'testimonial_quote_author_title',
        'type' => 'text',
    ));
    /**
     * CMB2 metaboxes for success cpt custom fields
     */
    $cnmi_success_fields = new_cmb2_box(array(
        'id' => $prefix . 'success_meta',
        'title' => esc_html__('Additional Info', 'cmb2'),
        'object_types' => array('success'), // Post type
        // 'show_on_cb' => 'cnmi_show_if_front_page', // function should return a bool value
        // 'context'    => 'normal',
        // 'priority'   => 'high',
        // 'show_names' => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // true to keep the metabox closed by default
        // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
        // 'classes_cb' => 'cnmi_add_some_classes', // Add classes through a callback.
    ));

    $cnmi_success_fields->add_field(array(
        'name' => 'Subtitle',
        'desc' => 'to be displayed under the Page Title in certain areas',
        'default' => '',
        'id' => 'success_subtitle',
        'type' => 'text',
    ));

    $cnmi_success_fields->add_field(array(
        'name' => 'Quote',
        'desc' => 'a quote that will be prominently displayed on the story page',
        'default' => '',
        'id' => 'success_quote',
        'type' => 'textarea_small',
    ));

    $cnmi_success_fields->add_field(array(
        'name' => 'Quote Author',
        'desc' => 'attribution for the quote entered above, if applicable',
        'default' => '',
        'id' => 'success_quote_author',
        'type' => 'text',
    ));

    $cnmi_success_fields->add_field(array(
        'name' => 'Author Title',
        'desc' => 'Does the quote author above have a title you want displayed? If so, put it here!',
        'default' => '',
        'id' => 'success_quote_author_title',
        'type' => 'text',
    ));
    /**
     * CMB2 metaboxes for news cpt custom fields
     */
    $cnmi_news_fields = new_cmb2_box(array(
        'id' => $prefix . 'news_meta',
        'title' => esc_html__('Additional Info', 'cmb2'),
        'object_types' => array('news'), // Post type
        // 'show_on_cb' => 'cnmi_show_if_front_page', // function should return a bool value
        // 'context'    => 'normal',
        // 'priority'   => 'high',
        // 'show_names' => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // true to keep the metabox closed by default
        // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
        // 'classes_cb' => 'cnmi_add_some_classes', // Add classes through a callback.
    ));

    $cnmi_news_fields->add_field(array(
        'name' => 'Pull Quote',
        'desc' => 'a quote that will be pulled into certain related theme pages',
        'default' => '',
        'id' => 'news_pull_quote',
        'type' => 'textarea_small'
    ));

    $cnmi_news_fields->add_field(array(
        'name' => 'Pull Quote Author',
        'desc' => 'attribution for the pull quote entered above, if applicable',
        'default' => '',
        'id' => 'news_pull_quote_author',
        'type' => 'textarea_small'
    ));

    $cnmi_news_fields->add_field(array(
        'name' => esc_html__('Website URL', 'cmb2'),
        'desc' => esc_html__('enter the original website URL for this news story', 'cmb2'),
        'id' => $prefix . 'news-site-url',
        'type' => 'text_url',
        'protocols' => array('http', 'https'), // Array of allowed protocols
        'repeatable' => false,
    ));
    /**
     * CMB2 metaboxes for staff cpt custom fields
     */
    $cnmi_staff_fields = new_cmb2_box(array(
        'id' => $prefix . 'staff_meta',
        'title' => esc_html__('Additional Info', 'cmb2'),
        'object_types' => array('staff'), // Post type
        // 'show_on_cb' => 'cnmi_show_if_front_page', // function should return a bool value
        // 'context'    => 'normal',
        // 'priority'   => 'high',
        // 'show_names' => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // true to keep the metabox closed by default
        // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
        // 'classes_cb' => 'cnmi_add_some_classes', // Add classes through a callback.
    ));

    $cnmi_staff_fields->add_field(array(
        'name' => 'Staff Title',
        'desc' => 'Put the Title of the staff member in this field',
        'default' => '',
        'id' => 'staff_title',
        'type' => 'text',
    ));

    $cnmi_staff_fields->add_field(array(
        'name' => 'Fun Fact',
        'desc' => 'Share a Fun Fact quote from the staff member that will display in the Staff Card in About Page',
        'default' => '',
        'id' => 'staff_fun_quote',
        'type' => 'textarea_small'
    ));

    $cnmi_staff_fields->add_field(array(
        'name' => esc_html__('Staff Email Address', 'cmb2'),
        // 'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
        'id' => $prefix . 'staff_email',
        'type' => 'text_email',
        // 'repeatable' => true,
    ));
    /**
     * CMB2 metaboxes for partner cpt custom fields
     */
    $cnmi_partner_fields = new_cmb2_box(array(
        'id' => $prefix . 'partner_meta',
        'title' => esc_html__('Additional Info', 'cmb2'),
        'object_types' => array('partner'), // Post type
        // 'show_on_cb' => 'cnmi_show_if_front_page', // function should return a bool value
        // 'context'    => 'normal',
        // 'priority'   => 'high',
        // 'show_names' => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // true to keep the metabox closed by default
        // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
        // 'classes_cb' => 'cnmi_add_some_classes', // Add classes through a callback.
    ));

    $cnmi_partner_fields->add_field(array(
        'name' => esc_html__('Website URL', 'cmb2'),
        'desc' => esc_html__('enter a URL to partner\'s website if available', 'cmb2'),
        'id' => $prefix . 'partner-url',
        'type' => 'text_url',
        'protocols' => array('http', 'https'), // Array of allowed protocols
        'repeatable' => false,
    ));

    $cnmi_partner_fields->add_field(array(
        'name' => esc_html__('Logo Image', 'cmb2'),
        'desc' => esc_html__('Upload an image or enter a URL to display the logo for this partner', 'cmb2'),
        'id' => $prefix . 'partner-logo',
        'type' => 'file',
    ));
    /**
     * CMB2 metaboxes for impact page custom fields
     */
    $cnmi_impact_meta = new_cmb2_box(array(
        'id' => 'impact-information',
        'title' => 'Additional Information',
        'object_types' => array('page'), // post type
        'show_on' => array('key' => 'page-template', 'value' => 'page-impact.php'),
        'context' => 'normal', //  'normal', 'advanced', or 'side'
        'priority' => 'high',  //  'high', 'core', 'default' or 'low'
        'show_names' => true, // Show field names on the left
    ));

    $cnmi_impact_meta->add_field(array(
        'name' => esc_html__('Home Page Image', 'cmb2'),
        'desc' => esc_html__('Upload an image or enter a URL to display the infographic or main impact image on both the home page and Impact page', 'cmb2'),
        'id' => $prefix . 'infographic',
        'type' => 'file',
    ));

    $cnmi_impact_meta->add_field(array(
        'name' => 'Infographic Title',
        'desc' => 'title for image uploaded above - displayed on home page and Impact page',
        'default' => '',
        'id' => 'infograph_title',
        'type' => 'text_medium'
    ));

    $cnmi_impact_meta->add_field(array(
        'name' => 'Infographic Description',
        'desc' => 'text for image uploaded above - displayed on home page and Impact page',
        'default' => '',
        'id' => 'infograph_description',
        'type' => 'textarea'
    ));

    /**
     * CMB2 metaboxes for Board of Directors CPT custom fields
     */
    $cnmi_board_meta = new_cmb2_box(array(
        'id' => $prefix . 'board_meta',
        'title' => esc_html__('Additional Info', 'cmb2'),
        'object_types' => array('board'), // post type
        'context' => 'normal', //  'normal', 'advanced', or 'side'
        'priority' => 'high',  //  'high', 'core', 'default' or 'low'
        'show_names' => true, // Show field names on the left
    ));

    $cnmi_board_meta->add_field(array(
        'name' => esc_html__('Board Title', 'cmb2'),
        'desc' => esc_html__('What is this person\'s title on the CNM Ingenuity Board of Directors?', 'cmb2'),
        'default' => '',
        'id' => 'board_title',
        'type' => 'text',
    ));

    $cnmi_board_meta->add_field(array(
        'name' => 'Professional Title',
        'desc' => 'What is this person\'s title at their company or place of work?',
        'default' => '',
        'id' => 'board_professional_title',
        'type' => 'text',
    ));

    $cnmi_board_meta->add_field(array(
        'name' => 'Company',
        'desc' => 'the name of this person\'s company or place of work?',
        'default' => '',
        'id' => 'board_company',
        'type' => 'text',
    ));
}