<?php
/*Template Name: Partnership*/

//this forces full width layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the single page
remove_action('genesis_sidebar', 'genesis_do_sidebar');


//This is a loop that displays Programs in the database. If it has a logo, the CF will display that logo. If no logo, it will display the Title of the Program

remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_after_loop', 'genesis_partner_loop' );

function genesis_partner_loop() {
	echo '<div class="partner-container">';
	echo '<h3>Partners and Collaborators</h3>';
	echo '<div class="partner-loop-page">';
	if(have_posts()) : while(have_posts()) : the_post();

		$partnerLogo = wp_get_attachment_image(get_post_meta(get_the_ID(), 'cnmi_demo_partner-logo_id', 1), 'partner');
		$partner_url = get_post_meta(get_the_ID(), 'cnmi_demo_partner-url', true);
		if(!empty($partnerLogo)) {

			echo '<div class="partner-logo"><a href=" ' . $partner_url . '" target="_blank">' . $partnerLogo . '</a></div>';

		} else {
			echo '<div class="partner-logo"><a href="' . $partner_url . '" target="_blank"><p class="partner-name-archive">' . get_the_title() . '</p></a></div>';

		}

	endwhile;
	endif;

	echo '</div>';
	echo '</div>';
}

//Widget area for a CTA, which we can customize through the Dashboard->widgets->Partner - CTA
add_action('genesis_loop','custom_cta_partner');
function custom_cta_partner() {
	if(is_active_sidebar('partner-cta')){

	genesis_widget_area( 'partner-cta', array(
		'before' => '<div class="widget-area"><div class="wrap">',
		'after' => '</div></div>',
		) );
	}
}

genesis();