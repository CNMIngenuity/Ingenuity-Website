<?php
/**
 * Template: Success
 */

//this forces full width layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the single page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'impact_success' );


function impact_success() {
	echo '<div class="impact-success">';

//Arguments that you can pass through the function. We are displaying only the CPT 'News'
	$args = array(
		'post_type' => 'Success',
		'posts_per_page' => -1,
		'orderby' => 'date',
	);

//Loop through Custom Post Type in there are posts and if we are currently on a single page.  EDIT is_singular is now empty to show on all singular pages in general
	$loop = new WP_Query($args);
	if($loop->have_posts()):
		while($loop->have_posts()) {
			$loop->the_post();

			//This is a conditional that takes every other post in the loop, and flips the contents of the columns.
			if(0 == $loop->current_post % 2) {
				echo '<div class="impact-success-story success-story-a">';
				echo '<div class="one-third first">';
				echo '<p>' . get_the_post_thumbnail($post, 'medium') . '</p>';
				echo '</div>';
				echo '<div class="two-thirds">';
				echo the_title('<h4>', '</h4>' );
				echo the_excerpt();
				echo '<p><a class="read-more" href="' . get_the_permalink() . '">Read More &#62;&#62;</a>';
				echo '</div>';
				echo '<div class="clearfix"></div>';
				echo '</div>';
			} else {
				echo '<div class="impact-success-story success-story-b">';
				echo '<div class="one-third right">';
				echo '<p>' . get_the_post_thumbnail($post, 'medium') . '</p>';
				echo '</div>';
				echo '<div class="two-thirds first left">';
				echo the_title('<h4>', '</h4>');
				echo the_excerpt();
				echo '<p><a class="read-more" href="' . get_the_permalink() . '">Read More &#62;&#62;</a></p>';
				echo '</div>';
				echo '<div class="clearfix"></div>';
				echo '</div>';
			}
		}

	endif;
	echo '</div>';
	echo '<div class="clearfix"></div>';
	wp_reset_postdata();
}

genesis();