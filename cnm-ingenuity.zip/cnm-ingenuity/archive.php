<?php
/*Template Name: Archive Page*/

//this forces full width layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the single page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

/*removes post meta data which was underneath the feature image. We want it to include nothing, so we return empty string.*/
remove_action('genesis_entry_header', 'genesis_post_meta', 12);

/*removes post meta data which was underneath the feature image. We want it to include nothing, so we return empty string.*/

add_filter('genesis_post_meta', 'meta_info_filter');
function meta_info_filter($meta_info) {
	$meta_info = '';
	return $meta_info;
}

/*This adds a filter that over-rides the Genesis default of showing post info such as date and author. It returns an empty variable. If we want to show any of that, we include it after = and inside ''. Shows [post_date]*/

add_filter('genesis_post_info', 'post_info_filter');
function post_info_filter($post_info) {
	if(is_post_type_archive('news')) {
		$post_info = '[post_date]';
	}else {
		$post_info = '';
	}
	return $post_info;
}
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );

/*Removes the post content if there is an excerpt available*/

remove_action('genesis_entry_content', 'genesis_do_post_content');

/*Adds the excerpt if it is available*/

add_action('genesis_entry_content', 'excerpt_function', 12);
function excerpt_function() {

	the_excerpt();
}

add_action('genesis_entry_content', 'featured_image');
function featured_image() {
	if(is_post_type_archive('board')) {
		 the_post_thumbnail('medium');
	}
}


genesis();