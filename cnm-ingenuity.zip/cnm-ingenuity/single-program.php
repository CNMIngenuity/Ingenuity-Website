<?php
/**
 * Template Name: Program Single Page
 * Description: Used as a single page template for programs included in the Program Archive Page
 */

/*This adds a filter that over-rides the Genesis default of showing post info such as date and author. It returns an empty variable. If we want to show any of that, we include it after = and inside ''*/
add_filter('genesis_post_info', 'post_info_filter');
function post_info_filter($post_info) {
	$post_info = '';
	return $post_info;
}

// ----------------------------------------------------------------
// This function adds an extra class to single pages that we use in CSS to limit page width
add_filter( 'genesis_attr_content-sidebar-wrap', 'custom_add_css_attr' );

function custom_add_css_attr( $attributes ) {  
		$attributes['class'] .= ' squeeze'; 
   		return $attributes; 
}

/*removes post meta data which was underneath the feature image. We want it to include nothing, so we return empty string.*/
remove_action('genesis_entry_header', 'genesis_post_meta', 12);

add_filter('genesis_post_meta', 'meta_info_filter');
function meta_info_filter($meta_info) {
	$meta_info = '';
	return $meta_info;
}

// Hook after header area
add_action('genesis_after_header', 'hero_image');

//function to attach a Hero Image at the top of the Single Program Page using the Featured Image
function hero_image() {
// If it is a page and has a featured thumbnail, but is not the front page do the following...
	if(has_post_thumbnail()) {
		// Get hero image and save in variable called $background
		$image_desktop = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'large');
		$image_tablet = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'large');
		$image_mobile = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'medium_large');

		$bgdesktop = $image_desktop[0];
		$bgtablet = $image_tablet[0];
		$bgmobile = $image_mobile[0];

// You can change above-post-hero to any class you want and adjust CSS styles
		$featured_class = 'above-post-hero';

		?>
		<div class='<?php echo $featured_class; ?>'></div>
		<style>
			<?php echo ".$featured_class "; ?>
			{
				background-image: url( <?php echo $bgmobile; ?>)
			;
				height: 176px
			;
				background-size: cover
			;
			}

			@media only screen and (min-width: 480px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgtablet;?>);
				height: 276px;
				background-size: cover;
			}
			}

			@media only screen and (min-width: 992px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgdesktop;?>);
				height: 500px;
				background-size: cover;
			}
			}

			@media only screen and (min-width: 1200px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgdesktop;?>);
				height: 600px;
				background-size: cover;
			}
			}
		</style>
		<?php
	}

}

//Adding the function program_testimonials to the genesis_after_entry hook.
add_action('genesis_after_entry', 'program_testimonials');

//function to display the Custom Fields for Program Testimonials
function program_testimonials() {

	//assign CF's to variables in order to echo out
	$program_testimonials = get_post_meta(get_the_ID());

	//unserialize and display meta
	if(isset($program_testimonials['testimonial_group'][0])) {
	    $testimonials_list = maybe_unserialize($program_testimonials['testimonial_group'][0]);

		echo '<div class="testimonial-content">';
		foreach($testimonials_list as $testimonial) {
		echo '<div class="program-testimonial">';
		echo '<p class="quote">' . $testimonial['testimonial_quote'] . '</p>';
		echo '<p class="author">' . $testimonial['testimonial_quote_author'];
		echo '<br/>';
		echo '<span class="test-title">' . $testimonial['testimonial_quote_author_title'] . '</span></p>';
		echo '</div>';
	}
		echo '</div>';

	}
}


// Add action to use the logo and remove post title if logo has been uploaded. If it has not been uploaded, echo post title
	remove_action('genesis_entry_header', 'genesis_do_post_title');
	add_action('genesis_entry_header', 'use_logo');
	function use_logo() {
// Grab the metadata for Custom Field from the database and assign it to a variable
		$logo = get_post_meta(get_the_ID(), 'cnmi_demo_image', true);
		if(!empty($logo)) {
// Echo the metadata
			echo '<p class="logo"><img src="' . esc_html($logo) . '"></img></p>';
			} else {
			echo genesis_do_post_title();
		}
	}

//function to add Program URL if available
	add_action('genesis_entry_content', 'add_links', 12);
	function add_links() {
		echo '<div class="program-btn">';
// Grab the metadata from the database, and assign it to variable
		$prog_url = get_post_meta(get_the_ID(), 'cnmi_demo_program-site-url', true);
		$course_url = get_post_meta(get_the_ID(), 'cnmi_demo_url', true);
		if($prog_url) {
// Echo the metadata
			echo '<a class="button" href=" ' . $prog_url . '" target="_blank">Visit Website</a>';
			echo '<br/>';
		}
		if($course_url) {
			echo '<a class="button" href=" ' . $course_url . '" target="_blank">Sign up</a>';
			echo '<br/>';
		}
		echo '</div>';
		echo '<br/>';
		echo '<a href="' . get_post_type_archive_link('program') . '">View All Programs &#62;&#62;</a>';

	}

// Register custom sidebar for Single Program Pages only
	genesis_register_sidebar(array(
		'id' => 'single-program-sidebar',
		'name' => 'Single Program Sidebar',
		'description' => 'This is the sidebar for single program pages.',
	));

// Remove the Primary Sidebar for our Custom Sidebar
	add_action('get_header', 'change_genesis_sidebar');
	function change_genesis_sidebar() {
		if(is_singular('program')) { // change 'post_type' to your CPT slug name
			remove_action('genesis_sidebar', 'genesis_do_sidebar'); //remove the default genesis sidebar
			add_action('genesis_sidebar', 'category_news'); //add an action hook to call the function for my custom sidebar
		}
	}


// Output sidebar with the id 'sidebar-custom'
	function child_do_cpt_sidebar() {
		genesis_widget_area('sidebar-custom');
	}

	function category_news() {
//This piece of code is what tells WP that we will look for the category for the Single post we are currently on, and display in the widget similar posts that share that same category.
		echo '<h3 class="program-widget-title">Latest News</h3>';
		$category_main = get_the_category();
		$cat_slug = $category_main[0]->slug;
// echo $cat_slug; // This is just to see if I got the right output--> authors note to himself


        //Arguments that you can pass through the widget function. We are displaying only the CPT 'News' in our widget
        //Check if there's news with the same category as program
		$args1 = array(
			'post_type' => 'News',
			'posts_per_page' => 3,
			'category_name' => $cat_slug,
			'orderby' => 'date',

		);

        //If related category news does not exist, show latest news
        $args2 = array(
            'post_type' => 'News',
            'posts_per_page' => 3,
            'orderby' => 'date',

        );
        //Loop through Custom Post Type in there are posts and if we are currently on a single Program page. ('program' must be lowercase)
		$loop = new WP_Query($args1);

		if (!$loop->have_posts()) {
            $loop = new WP_Query($args2);
        }

		if(is_singular('program')):
			while($loop->have_posts()) {
				$loop->the_post();

				//   echo $cat_slug_course; // This is just to see if I got the right output --> authors note to himself
				//What will be displayed physically in the widget for each item
				if(has_post_thumbnail()) {
					echo '<div class="entry-content program-news">';
					echo '<div class="news-image">';
					the_post_thumbnail('thumbnail');
					echo '</div>';
					echo '<div class="news-stuff">';
					echo '<a href="' . get_the_permalink() . '">';
					echo '<h6>' . get_the_title() . '</h6>';
					echo '</a>';
					the_time('F jS, Y');
					echo '<br/>';
					echo '</div>';
					echo '</div>';
				} else {
					echo '<div class="entry-content program-news">';
					echo '<div class="news-image">';
					echo '<img src="' . get_stylesheet_directory_uri() . '/images/ingenuity-light-w.png" alt="CNM Logo" />';
					echo '</div>';
					echo '<div class="news-stuff">';
					echo '<a href="' . get_the_permalink() . '">';
					echo '<h6>' . get_the_title() . '</h6>';
					echo '</a>';
					the_time('F jS, Y');
					echo '<br/>';
					echo '</div>';
					echo '</div>';
				}
			}
		endif;

		wp_reset_postdata();
	}

	genesis();