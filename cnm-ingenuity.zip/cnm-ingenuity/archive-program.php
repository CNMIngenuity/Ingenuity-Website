<?php
/**
 * Template Name: Program Archives
 * Description: Used as a page template to show page contents, followed by a loop through a CPT archive
 */

//Adds a custom class, program-archive, for styling purposes
add_filter( 'body_class', 'archive_body_class' );
function archive_body_class( $classes ) {
	$classes[] = 'program-archive';
	return $classes;
}

//this forces full width layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the single page
remove_action('genesis_sidebar', 'genesis_do_sidebar');
//This is a loop that displays Programs in the database. If it has a logo, the CF will display that logo. If no logo, it will display the Title of the Program
remove_action('genesis_loop', 'genesis_do_loop');
add_action('genesis_loop', 'genesis_archive_loop');

function genesis_archive_loop() {
	echo '<ul id="hexGrid">';
	if(have_posts()) : while(have_posts()) : the_post();
	$excerpt = the_excerpt_max_charlength(100);
		//put the custom field for Program Hexagon Image into $programImage. Program will only show, on front page, if that variable is filled in the Dashboard
		$hexagonImage = wp_get_attachment_image(get_post_meta(get_the_ID(), 'hexagon-image_id', 1), 'hexagon');
		if(!empty($hexagonImage)) {
            echo '<li class="hex">
						<div class="hexIn">
						<a class="hexLink" href="' . get_the_permalink() . '">
							<img src="' . $hexagonImage . '" alt="some text" />
							<div class="program-title">'. get_the_title() .'</div>
							<div class="hex-overlay">
							<div class="hex-overlay-text">' . $excerpt . '</div>
							</div>
						</a>
						</div>
					  </li>';
		}
	
	endwhile;
	endif;
	echo '</ul>';
}

genesis();


