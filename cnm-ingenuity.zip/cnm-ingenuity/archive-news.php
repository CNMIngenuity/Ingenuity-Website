<?php
/**
 * Template: News
 **/

//this forces full width layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the single page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

//Function that displays Latest News on Home Page
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'news_archive' );

function news_archive() {
	echo '<div class="news-archive-block">';
	$newsArchiveLink = get_post_type_archive_link( 'news' );
	//Arguments that you can pass through the widget function. We are displaying only the CPT 'News' in our widget
	$args = array(
		'post_type' => 'News',
		'posts_per_page' => -1,
		'orderby' => 'date',
	);

	//Loop through Custom Post Type in there are posts and if we are currently on a single Program page. ('program' must be lowercase)
	$loop = new WP_Query($args);
	if($loop->have_posts()):
		while($loop->have_posts()) {
			$loop->the_post();
			//What will be displayed physically in the widget for each item
			if(has_post_thumbnail()){
				echo '<div class="entry-content news-card">';
				echo '<a href=' . get_the_permalink() . '">';
				the_post_thumbnail('featured');
				echo '<br />';
				the_time('F jS, Y');
				echo '<h6>' . get_the_title() . '</h6>';
				echo '</a>';
				echo '<a class="read-more" href=' . get_the_permalink() . '">Read More &#62;&#62;</a>';
				echo '</div>';
			} else {
				echo '<div class="entry-content news-card">';
				echo '<a href=' . get_the_permalink() . '">';
				echo '<img src="'. get_stylesheet_directory_uri() .'/images/ingenuity-logo-300w.png" alt="CNM Logo" />';
				echo '<br />';
				the_time('F jS, Y');
				echo '<br />';
				echo '<h6>' . get_the_title() . '</h6>';
				echo '</a>';
				echo '<a class="read-more" href=' . get_the_permalink() . '">Read More &#62;&#62;</a>';
				echo '</div>';
			}
		}
	endif;
	wp_reset_postdata();
	echo '</div>';
	echo '</div>';
}



genesis();