<?php

 /*Template Name: Partnership*/

//This forces full width page layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the About Page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

add_action( 'genesis_before_loop', 'genesis_do_search_title' );

/*This adds a filter that over-rides the Genesis default of showing post info such as date and author. It returns an empty variable. If we want to show any of that, we include it after = and inside ''*/
add_filter('genesis_post_info', 'post_info_filter');
function post_info_filter($post_info) {
	$post_info = '';
	return $post_info;
}

/*removes post meta data which was underneath the feature image. We want it to include nothing, so we return empty string.*/
remove_action('genesis_entry_header', 'genesis_post_meta', 12);

add_filter('genesis_post_meta', 'meta_info_filter');
function meta_info_filter($meta_info) {
	$meta_info = '';
	return $meta_info;
}

function genesis_do_search_title() {

	$title = sprintf( '<div class="archive-description"><h1 class="archive-title">%s %s</h1></div>', apply_filters( 'genesis_search_title_text', __( 'Search Results for:', 'genesis' ) ), get_search_query() );

	echo apply_filters( 'genesis_search_title_output', $title ) . "\n";

}
genesis();