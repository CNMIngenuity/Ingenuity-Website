<?php
/*Template Name: About*/


//This forces full width page layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the About Page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

// Hook after header area
add_action('genesis_after_header', 'hero_image');

//function to attach a Hero Image at the top of the Single Program Page using the Featured Image
function hero_image() {
// If it is a page and has a featured thumbnail, but is not the front page do the following...
	if(has_post_thumbnail()) {
		// Get hero image and save in variable called $background
		$image_desktop = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'hero-image');
		$image_tablet = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'large');
		$image_mobile = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'medium');

		$bgdesktop = $image_desktop[0];
		$bgtablet = $image_tablet[0];
		$bgmobile = $image_mobile[0];

// You can change above-post-hero to any class you want and adjust CSS styles
		$featured_class = 'above-post-hero';

		?>
		<div class='<?php echo $featured_class; ?>'></div>
		<style>
			<?php echo ".$featured_class "; ?>
			{
				background-image: url( <?php echo $bgmobile; ?>)
			;
				height: 176px
			;
				background-size: cover
			;
			}

			@media only screen and (min-width: 480px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgtablet;?>);
				height: 276px;
				background-size: cover;
			}
			}

			@media only screen and (min-width: 992px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgdesktop;?>);
				height: 400px;
				background-size: cover;
			}
			}
		</style>
		<?php
	}

}

/*---------------------------------------------------------------------------------------*/
//Function that adds a CTA section to the page with custom fields from impact page

/*add_action('genesis_after_entry', 'impact_cta', 5);
function impact_cta(){
	$impact= get_page_by_title( 'impact');
	$impact_id = $impact->ID;
	$impact_link = get_page_link($impact_id);
	$impactInfo = wp_get_attachment_image(get_post_meta($impact_id, 'cnmi_demo_infographic_id', true), 'medium');
	echo '<div class="about-impact">';
	echo '<div class="one-half first">';
	echo $impactInfo;
//    echo '<img src="' . $impactInfo . '"</img>';
	echo '</div>';//close two-thirds div
	echo '<div class="one-half">';
	//echo '<h3>' . $impactTitle . '</h3>';
	//echo '<p>' . $impactDesc . '</p>';   Leaving these here just in case we want to include them
	echo'<p><a href="' . $impact_link . '" class="button">Learn About Our Impact</a></p>';
	echo '</div>'; //close one-third div with text inside
	echo '</div>';
	echo '<div class="clearfix"> </div>';
}*/

add_action('genesis_entry_footer', 'custom_cta_about');

function custom_cta_about() {
	echo '<div class="about-impact">';
	if(is_active_sidebar('about-cta')){

		genesis_widget_area( 'about-cta', array(
			'before' => '<div class="widget-area">',
			'after' => '</div>',
		) );
	}
	echo '</div>';
}

//Function that displays a loop of CPT 'Staff'
add_action('genesis_after_entry', 'about_staff', 6);

function about_staff() {
	echo '<div class="staff-container">';
	echo '<p><h3 class="staff-title">Meet Our Team</h3></p>';
	echo '<div class="staff-section">';

//Arguments that you can pass through the function. We are displaying only the CPT 'Staff'
	$args = array(
		'post_type' => 'Staff',
		'posts_per_page' => -1,
		'orderby' => 'date',

	);
//Loop through Custom Post Type, which 'will display the Staff CPT if it has posts
	$loop = new WP_Query($args);

	if($loop->have_posts() && is_singular('')):
		while($loop->have_posts()) {

			$loop->the_post();
			$staffEmail = get_post_meta(get_the_ID(), 'cnmi_demo_staff_email', true);
			$staffFunFact = get_post_meta(get_the_ID(), 'staff_fun_quote', true);
			$staffTitle = get_post_meta(get_the_ID(), 'staff_title', true);

			//What will be displayed physically for each item in loop
		if($staffFunFact) {
			echo '<div class="entry-content staff-card">';
			the_post_thumbnail('staff');
			echo '<br />';
			echo '<h6>' . get_the_title() . '</h6>';
			echo '<p class="staff-title">' . $staffTitle . '</p>';
			echo '<p class="ttt">' . the_content() . '</p>';
			echo '<p class="fun-fact">' . $staffFunFact . '</p>';
			echo '<a href="mailto:' . $staffEmail . '">' . $staffEmail . '</a>';
			echo '</div>';
		} else {
			echo '<div class="entry-content staff-card">';
			the_post_thumbnail('staff');
			echo '<br />';
			echo '<h6>' . get_the_title() . '</h6>';
			echo '<p class="ttt">' . the_content() . '</p>';
			//echo '<p class="fun-fact"><strong>Fun Fact:</strong>' . $staffFunFact . '</p>';
			echo '<a href="mailto:' . $staffEmail . '">' . $staffEmail . '</a>';
			echo '</div>';
		}
		}endif;

	wp_reset_postdata();
	echo '</div>';
	echo '</div>';
	echo '<div class="clearfix"></div>';
}

/*---------------------------------------------------------------------------------------*/


//Function that displays a loop of CPT 'Board of Directors'
add_action('genesis_after_entry_content', 'about_board', 4);
function about_board() {
	echo '<div class="about-board">';
	echo '<h3 class="board-title">Our Board of Directors</h3>';
//Arguments that you can pass through the function. We are displaying only the CPT 'Board of Directors'
	$args = array(
		'post_type' => 'board',
		'posts_per_page' => -1,
		'orderby' => 'date',
	);
//Loop through Custom Post Type, which will display the Board of Directors CPT if it has posts

	$loop = new WP_Query($args);
	echo '<ul id="hexGrid">';
	if($loop->have_posts()):
		while($loop->have_posts()) {
			$loop->the_post();
			$board_title = get_post_meta(get_the_ID(), 'board_title', true);
			$board_prof_title = get_post_meta(get_the_ID(), 'board_professional_title', true);
			$board_company = get_post_meta(get_the_ID(), 'board_company', true);
			if(!empty(get_the_post_thumbnail_url())) {
				echo '<li class="hex">
						<div class="hexIn">
						<a onclick="return false" class="hexLink no-link" href="">
							<img src="' . get_the_post_thumbnail_url($post->ID, 'hexagon') . '" alt="" />
							<h1>' . get_the_title() . '<br/>' . $board_title . '</h1>
							<p>' . $board_prof_title . '<br/>' . $board_company . '</p>
						</a>
						</div>
					  </li>';
			}
		}
	endif;
	echo '</ul>';
	echo '</div>';
	echo '<div class="clearfix"></div>';
	wp_reset_postdata();
}



//Function that displays Partners on Home Page
add_action('genesis_after_loop', 'about_partners', 10);
function about_partners() {
	//echo '<div class="home-partners">';
	echo '<div class="partner-about-container">';
	echo '<h3>Our Partners and Collaborators</h3>';
    echo '<div class="partner-slider">';
    echo '<div class="partner-loop">';
    //Arguments that you can pass through the widget function. We are displaying only the CPT 'News' in our widget
    $args = array(
        'post_type' => 'Partner',
        'posts_per_page' => -1,
        'orderby' => 'date',
    );
    //Loop through Custom Post Type in there are posts and if we are currently on a single Program page. ('program' must be lowercase)
    $loop = new WP_Query($args);
    $i = 0;
    if($loop->have_posts()):
        while($loop->have_posts()) {
            $i++;
            $loop->the_post();
            $partnerLogo = wp_get_attachment_image(get_post_meta(get_the_ID(), 'cnmi_demo_partner-logo_id', 1), 'partner');
            $partner_url = get_post_meta(get_the_ID(), 'cnmi_demo_partner-url', true);
            if(!empty($partnerLogo)) {

                echo '<div class="partner-logo';
                if($i == 1) { echo ' first-logo';}
                echo '"><a href=" ' . $partner_url . '" target="_blank">' . $partnerLogo . '</a></div>';

            } else {
                echo '<div class="partner-logo"><a href="' . $partner_url . '" target="_blank"><p class="partner-name-archive">' . get_the_title() . '</p></a></div>';

            }
        }

	endif;

	echo '</div>';
	echo '<p><a class="button" href="' . get_post_type_archive_link('partner') . '">More About Our Partners</a></p>';

	echo '</div>';
}
genesis();

