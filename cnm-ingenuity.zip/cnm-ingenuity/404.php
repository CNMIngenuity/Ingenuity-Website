<?php
/**
 * Created by PhpStorm.
 * User: Esteban
 * Date: 5/25/2018
 * Time: 2:57 PM
 */
//This forces full width page layout
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
//Remove sidebar on the About Page
remove_action('genesis_sidebar', 'genesis_do_sidebar');

// Remove default loop.
remove_action( 'genesis_loop', 'genesis_do_loop' );

add_action( 'genesis_loop', 'genesis_404' );
function genesis_404(){
	echo '<div class="error-page">';
	echo '<h2 class="error-title">Page not Found</h2>';
	echo '<h4 class="error-text">The page you\'re looking for does not exist or has been moved. 
	<br/>Please return to the <span class="home-redirect"><a href="' .  home_url() . '">Home page</a></span></h4>';

	get_search_form();
	echo '</div>';
}

genesis();