<?php
/**
 * Executive Pro.
 *
 * This file adds the front page to the Executive Pro Theme.
 *
 * @package Executive
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://my.studiopress.com/themes/executive/
 */

add_action('genesis_meta', 'executive_home_genesis_meta');
/**
 * Add widget support for the front page. If no widgets active, display the default loop.
 *
 * @since 3.0.0
 */
function executive_home_genesis_meta() {

		remove_action('genesis_loop', 'genesis_do_loop');
		add_action('genesis_loop', 'executive_home_sections');
		add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');
		add_filter('body_class', 'executive_add_home_body_class');

}


	
// Widget areas to output on the front page.
function executive_home_sections() {

	echo '<h2 class="screen-reader-text">' . __('Main Content', 'executive-pro') . '</h2>';

	genesis_widget_area('home-top', array(
		'before' => '<div class="home-top widget-area">',
		'after' => '</div>',
	));

	// genesis_widget_area('home-cta', array(
	// 	'before' => '<div class="home-cta widget-area">',
	// 	'after' => '</div>',
	// ));

	genesis_widget_area('home-middle', array(
		'before' => '<div class="home-middle widget-area">',
		'after' => '</div>',
	));

}

//Hooking Slider Widget outside of wrap

add_action('genesis_loop', 'slider_widget', 1);

//HOME SLIDER WIDGET

function slider_widget() {
	genesis_widget_area('home-slider', array(
		'before' => '<div class="home-slider widget-area">',
		'after' => '</div>',
	));
}

add_action('genesis_after_loop', 'home_programs', 1);
function home_programs() {
	echo '<div class="home-programs"><h3>Our Programs and Initiatives</h3>';
	//Arguments that you can pass through the widget function. We are displaying only the CPT 'News' in our widget

	$args = array(
		'post_type' => 'Program',
		'posts_per_page' => 8,
		'orderby' => 'date',
	);
	 
	//Loop through Custom Post Type if there are posts
	$loop = new WP_Query($args);
	echo '<ul id="hexGrid">';
	if($loop->have_posts()):
		while($loop->have_posts()) {

			$loop->the_post();
			$excerpt = the_excerpt_max_charlength(100);
			//put the custom field for Program Hexagon Image into $programImage. Program will only show, on front page, if that variable is filled in the Dashboard
			$hexagonImage = wp_get_attachment_image(get_post_meta(get_the_ID(), 'hexagon-image_id', 1), 'hexagon');

			if(!empty($hexagonImage)) {
				echo '<li class="hex">
						<div class="hexIn">
						<a class="hexLink" href="' . get_the_permalink() . '">
							<img src="' . $hexagonImage . '" alt="some text" />
							<div class="program-title">'. get_the_title() .'</div>
							<div class="hex-overlay">
							<div class="hex-overlay-text">' . $excerpt . '</div>
							</div>
						</a>
						</div>
					  </li>';
			}
		}

	endif;
	echo '<li class="hex last">
		<div class="hexIn">
			<a class="hexLink" href="/program">
				<img src="" alt="" />
				<div class="last-program-title">View All Programs &#xbb;</div>
				<p></p>
			</a>
		</div>
  	</li>';
	echo '</ul> </div>';
	echo '<div class="clearfix"> </div>';
	wp_reset_postdata();
}

//This will add a section for the "about" info
add_action('genesis_after_loop', 'home_about_section', 3);
function home_about_section () {
	$about = get_page_by_path( 'about' );
	$about_id = $about->ID;
	$about_link = get_the_permalink($about_id);
	$about_excerpt = $about->post_excerpt;
	$about_title = $about->post_title;
	echo '<div class="home-about">';
		echo '<div class="two-thirds first">';
			echo '<a href="' . $about_link . '"><h3>About CNM Ingenuity</h3></a>';
			echo '<p>' . $about_excerpt . '</p>';
			echo '<a class="light-link" href="' . $about_link . '">Go To About Page</a>';
		echo '</div>';
		echo '<div class="one-third">';
			echo get_the_post_thumbnail($about_id, 'medium', array( 'class' => 'home-about-img' ));
		echo '</div>';
	echo '</div>';
	echo '<div class="clearfix"> </div>';
}

//This will add a section for the "impact" info
add_action('genesis_after_loop', 'home_impact_section', 5);
function home_impact_section () {
	// Grab the custom fields from the impact page
	//Using the page title to grab the page and find ID
	$impact= get_page_by_path( 'impact');
	$impact_id = $impact->ID;
	$infograph = get_post_meta($impact_id, 'cnmi_demo_infographic', true);
	$impactTitle = get_post_meta($impact_id, 'infograph_title', true);
	$impactDesc = get_post_meta($impact_id, 'infograph_description', true);
	$impactPermalink = get_the_permalink($impact_id);
	// Echo them on the page
	echo '<div class="home-impact">';
	echo '<div class="one-half first">';
	echo '<img src="' . $infograph . '"></img>';
	echo '</div>';//close two-thirds div 
	echo '<div class="one-half">';
	echo '<h3>' . $impactTitle . '</h3>';
	echo '<p>' . $impactDesc . '</p>';
	echo '<a class="button" href="' . $impactPermalink . '">Learn More About Our Impact</a>';
	echo '</div>'; //close one-third div with text inside
	echo '</div>';
	echo '<div class="clearfix"> </div>';
}

//Function that displays Latest News on Home Page
add_action('genesis_after_loop', 'home_news', 7);
function home_news() {
	$newsArchiveLink = get_post_type_archive_link( 'news' );
	echo '<div class="home-news"><a href="' . $newsArchiveLink . '"><h3 class="news-title">Latest News</h3></a>';
	echo '<div class="home-news-container">';
	//Arguments that you can pass through the widget function. We are displaying only the CPT 'News' in our widget
	$args = array(
		'post_type' => 'News',
		'posts_per_page' => 3,
		'orderby' => 'date',
	);

    //Loop through Custom Post Type in there are posts and if we are currently on a single Program page. ('program' must be lowercase)
    $loop = new WP_Query($args);
    if($loop->have_posts()):
        while($loop->have_posts()) {
            $loop->the_post();
            //What will be displayed physically in the widget for each item
			  if(has_post_thumbnail()){
            echo '<div class="entry-content news-card">';
            echo '<a href=' . get_the_permalink() . '">';
            the_post_thumbnail('featured');
            echo '<br />';
            the_time('F jS, Y');
            echo '<h6>' . get_the_title() . '</h6>';
            echo '</a>';
            echo '<a class="read-more" href=' . get_the_permalink() . '">Read More &#62;&#62;</a>';
            echo '</div>';
        } else {
				  echo '<div class="entry-content news-card">';
				  echo '<a href=' . get_the_permalink() . '">';
				  echo '<img src="'. get_stylesheet_directory_uri() .'/images/ingenuity-logo-300w.png" alt="CNM Logo" />';
				  echo '<br />';
				  the_time('F jS, Y');
				  echo '<br />';
				  echo '<h6>' . get_the_title() . '</h6>';
				  echo '</a>';
				  echo '<a class="read-more" href=' . get_the_permalink() . '">Read More &#62;&#62;</a>';
				  echo '</div>';
			  }
		  }
    endif;
	echo '</div>';
	echo '<div class="more-news-button">';
	echo '<br><a class="button more-news" href="' . $newsArchiveLink . '">View All News</a>';
	echo '</div>';
	wp_reset_postdata();
	echo '</div>';
}

//Function that displays Partners on Home Page
add_action('genesis_after_loop', 'home_partners', 10);
function home_partners() {
	//echo '<div class="home-partners">';
	echo '<div class="partner-home-container">';
	echo '<h3>Partners and Collaborators </h3>';
	echo '<div class="partner-slider">';
    echo '<div class="partner-loop">';
	//Arguments that you can pass through the widget function. We are displaying only the CPT 'News' in our widget
	$args = array(
		'post_type' => 'Partner',
		'posts_per_page' => -1,
		'orderby' => 'date',
	);
	//Loop through Custom Post Type in there are posts and if we are currently on a single Program page. ('program' must be lowercase)
	$loop = new WP_Query($args);
    $i = 0;
	if($loop->have_posts()):
		while($loop->have_posts()) {
	        $i++;
			$loop->the_post();
			$partnerLogo = wp_get_attachment_image(get_post_meta(get_the_ID(), 'cnmi_demo_partner-logo_id', 1), 'partner');
			$partner_url = get_post_meta(get_the_ID(), 'cnmi_demo_partner-url', true);
			if(!empty($partnerLogo)) {

				echo '<div class="partner-logo';
				if($i == 1) { echo ' first-logo';}
				echo '"><a href=" ' . $partner_url . '" target="_blank">' . $partnerLogo . '</a></div>';

			} else {
				echo '<div class="partner-logo"><a href="' . $partner_url . '" target="_blank"><p class="partner-name-archive">' . get_the_title() . '</p></a></div>';

			}
		}

	endif;

			echo '</div></div>';
	echo '<p><a class="button" href="' . get_post_type_archive_link('partner') . '">See all of our Partners</a></p>';

	echo '</div>';
		}


// Add body class to home page.
function executive_add_home_body_class($classes) {

	$classes[] = 'executive-pro-home';

	return $classes;

}

// Run the Genesis loop.
genesis();
