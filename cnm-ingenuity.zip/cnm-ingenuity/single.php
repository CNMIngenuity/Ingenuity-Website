<?php
/**
 *Template Name: Single Page
 */

// ----------------------------------------------------------------
// This function adds an extra class to single pages that we use in CSS to limit page width
add_filter( 'genesis_attr_content-sidebar-wrap', 'custom_add_css_attr' );

function custom_add_css_attr( $attributes ) {  
		$attributes['class'] .= ' squeeze'; 
   		return $attributes; 
} 
/*removes post meta data which was underneath the feature image. We want it to include nothing, so we return empty string.*/
add_filter('genesis_post_meta', 'meta_info_filter');
function meta_info_filter($meta_info) {
	$meta_info = '';
	return $meta_info;
}

/*This adds a filter that over-rides the Genesis default of showing post info such as date and author. It returns an empty variable. If we want to show any of that, we include it after = and inside ''. Shows [post_date]*/

add_filter('genesis_post_info', 'post_info_filter');
function post_info_filter($post_info) {
	if(is_singular('news')) {
		$post_info = '[post_date]';
	}else {
		$post_info = '';
	}
	return $post_info;
}

//This is a function that take the Featured Image and makes a full width Hero Image. It is hooked below the menu, above content


//function to attach a Hero Image at the top of the Single Program Page using the Featured Image

// Hook after header area
add_action('genesis_after_header', 'hero_image');

//function to attach a Hero Image at the top of the Single Program Page using the Featured Image
function hero_image() {
// If it is a page and has a featured thumbnail, but is not the front page do the following...
	if(has_post_thumbnail() && is_single()) {
		// Get hero image and save in variable called $background
		$image_desktop = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'large');
		$image_tablet = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'large');
		$image_mobile = wp_get_attachment_image_src(get_post_thumbnail_id($page->ID), 'medium');

		$bgdesktop = $image_desktop[0];
		$bgtablet = $image_tablet[0];
		$bgmobile = $image_mobile[0];

// You can change above-post-hero to any class you want and adjust CSS styles
		$featured_class = 'above-post-hero';

		?>
		<div class='<?php echo $featured_class; ?>'></div>
		<style>
			<?php echo ".$featured_class "; ?>
			{
				background-image: url( <?php echo $bgmobile; ?>);
				height: 176px;
				background-size: cover;
			}

			@media only screen and (min-width: 480px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgtablet;?>);
				height: 276px;
				background-size: cover;
			}
			}

			@media only screen and (min-width: 992px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgdesktop;?>);
				height: 500px;
				background-size: cover;
			}
			}

			@media only screen and (min-width: 1200px) {
			<?php echo ".$featured_class "; ?> {
				background-image: url(<?php echo $bgdesktop;?>);
				height: 600px;
				background-size: cover;
			}
			}
		</style>
		<?php
	}

}

//This forces Genesis to show the thumbnail for board members if they're available
add_action('genesis_before_loop', 'show_feature_image');
function show_feature_image() {
	if(has_post_thumbnail() && is_singular('board')) {
		the_post_thumbnail();
	}
}

// Register custom sidebar for Single Program Pages only
genesis_register_sidebar(array(
	'id' => 'single-program-sidebar',
	'name' => 'Single Program Sidebar',
	'description' => 'This is the sidebar for single program pages.',
));

// Remove the Primary Sidebar for our Custom Sidebar
add_action('get_header', 'single_page_sidebar');
function single_page_sidebar() {
	if(is_singular('')) { // change 'post_type' to your CPT slug name
		remove_action('genesis_sidebar', 'genesis_do_sidebar'); //remove the default genesis sidebar
		add_action('genesis_sidebar', 'single_news'); //add an action hook to call the function for my custom sidebar
	}
}

// Output sidebar with the id 'sidebar-custom'
function child_do_cpt_sidebar() {
	genesis_widget_area('sidebar-custom');
}

//function that adds News stories to the side of a single.php page
function single_news() {
	echo '<h3 class="program-widget-title">Latest News</h3>';

//Arguments that you can pass through the widget function. We are displaying only the CPT 'News' in our widget
	$args = array(
		'post_type' => 'News',
		'posts_per_page' => 3,
		'orderby' => 'date',
	);
//Loop through Custom Post Type in there are posts and if we are currently on a single Program page. ('program' must be lowercase)
	$loop = new WP_Query($args);
	if($loop->have_posts() && is_singular()):
		while($loop->have_posts()) {
			$loop->the_post();

			echo '<div class="entry-content program-news">';
			echo '<div class="news-image">';
			the_post_thumbnail('thumbnail');
			echo '</div>';
			echo '<div class="news-stuff">';
			echo '<a href="' . get_the_permalink() . '">';
			echo '<h6>' . get_the_title() . '</h6>';
			echo '</a>';
			the_time('F jS, Y');
			echo '<br/>';
			echo '</div>';
			echo '</div>';
		}

	else:

		// use css to hide related news section, if empty
		wp_enqueue_style('hide-sidebar', get_stylesheet_directory_uri() . '/css/hide-sidebar.css');

	endif;
	wp_reset_postdata();

}

//If the end user is on a Single NEWS page, it will show the news pull quote information
add_action('genesis_before_entry_content', 'cf_single');
function cf_single() {

	$pullQuote = get_post_meta(get_the_ID(), 'news_pull_quote', true);
	$quoteAuthor = get_post_meta(get_the_ID(), 'news_pull_quote_author', true);

	if(!empty(trim($pullQuote)) && is_singular('news')) {
		echo '<div class="news-quote-container">';
		echo '<div class="news-quote-card">';
		echo '<p class="pull-quote">' . $pullQuote . '</p>';
		echo '<p class="pull-author">' . $quoteAuthor . '</p>';
		echo '</div>';
		echo '</div>';
	}
}

//This action and function will display a button on SINGLE NEWS PAGES to view the source of the news story if a URL is available through the CF in dashboard
add_action('genesis_entry_content', 'news_url', 12);
function news_url() {
	$newsUrl = get_post_meta(get_the_ID(), 'cnmi_demo_news-site-url', true);

	if(!empty(trim($newsUrl)) && is_singular('news')) {
		echo '<a class="button" href=" ' . $newsUrl . '" target="_blank">Visit News Source</a>';
	}
}

//If the end user is on a Single NEWS page, it will show the news pull quote information
add_action('genesis_before_entry_content', 'success_pull');
function success_pull() {
	$successQuote = get_post_meta(get_the_ID(), 'success_quote', true);
	$successAuthor = get_post_meta(get_the_ID(), 'success_quote_author', true);
	$successTitle = get_post_meta(get_the_ID(), 'success_quote_author_title', true);
	if(!empty(trim($successQuote)) && is_single('success')) {
		echo '<div class="success-quote-container">';
		echo '<div class="news-quote-card">';
		echo '<p class="pull-quote">' . $successQuote . '</p>';
		echo '<p class="pull-author">' . $successAuthor;
		echo '<br />';
		echo $successTitle . '</p>';
		echo '</div>';
		echo '</div>';
	}
}

genesis();