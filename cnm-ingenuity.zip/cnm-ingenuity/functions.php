<?php
/**
 * CNM Ingenuity.
 *
 * This file adds the functions to the CNM Ingenuity Theme.
 *
 * @package CNM Ingenuity
 * @author  Ingenuity Software Labs
 * @license GPL-2.0+
 * @link    http://my.studiopress.com/themes/executive/
 */

// Start the engine.
require_once(get_template_directory() . '/lib/init.php');

// Setup Theme.
include_once(get_stylesheet_directory() . '/lib/theme-defaults.php');

// Set Localization (do not remove).
add_action('after_setup_theme', 'executive_localization_setup');
function executive_localization_setup() {
	load_child_theme_textdomain('executive-pro', get_stylesheet_directory() . '/languages');
}

// Add the theme helper functions.
include_once(get_stylesheet_directory() . '/lib/helper-functions.php');

// Add Color select to WordPress Theme Customizer.
require_once(get_stylesheet_directory() . '/lib/customize.php');

// Include Customizer CSS.
include_once(get_stylesheet_directory() . '/lib/output.php');

// Child theme (do not remove).
define('CHILD_THEME_NAME', __('Executive Pro', 'executive-pro'));
define('CHILD_THEME_URL', 'http://my.studiopress.com/themes/executive/');
define('CHILD_THEME_VERSION', '3.2.3');

// Add HTML5 markup structure.
add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));

// Add Accessibility support.
add_theme_support('genesis-accessibility', array('404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links'));

// Add viewport meta tag for mobile browsers.
add_theme_support('genesis-responsive-viewport');

// Add WooCommerce support.
include_once(get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php');

// Add the WooCommerce customizer styles.
include_once(get_stylesheet_directory() . '/lib/woocommerce/woocommerce-output.php');

// Include notice to install Genesis Connect for WooCommerce.
include_once(get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php');

// Enqueue fonts, scripts, and styles.
add_action('wp_enqueue_scripts', 'executive_load_scripts', 20);
function executive_load_scripts() {

	wp_enqueue_style('dashicons');

	wp_enqueue_style('google-font', '//fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700', array(), CHILD_THEME_VERSION);

	$suffix = (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG) ? '' : '.min';
	wp_enqueue_script('executive-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menus' . $suffix . '.js', array('jquery'), CHILD_THEME_VERSION, true);
	wp_localize_script(
		'executive-responsive-menu',
		'genesis_responsive_menu',
		executive_responsive_menu_settings()
	);
    wp_enqueue_script('jquery-slider', '//code.jquery.com/jquery-2.2.4.min.js');
    wp_enqueue_script('partner-slider', get_stylesheet_directory_uri() . '/js/partner-slider.min.js', array('jquery-slider'));
}

remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 100 );

// Includes cmb2 meta within the "includes" directory
require_once( dirname(__FILE__) . '/includes/cpt.php');

// Define our responsive menu settings.
function executive_responsive_menu_settings() {

	$settings = array(
		'mainMenu' => __('Menu', 'executive-pro'),
		'subMenu' => __('Submenu', 'executive-pro'),
		'menuClasses' => array(
			'combine' => array(
				'.nav-header',
				'.nav-primary',
			),
		),
	);

	return $settings;

}

// Add image sizes.
add_image_size( 'featured', 300, 101, array('center', 'top'));
add_image_size( 'hexagon', 300, 300, true);
add_image_size( 'staff', 300, 300, true);
add_image_size( 'partner', 200, 200, false);
add_image_size( 'hero-image', 1200, 501, array('center', 'top'));

// Add support for custom background.
// add_theme_support('custom-background');

/**
 * Filter the genesis_seo_site_title function to use an image for the logo instead of a background image
 * 
 * The genesis_seo_site_title function is located in genesis/lib/structure/header.php
 * @link http://blackhillswebworks.com/?p=4144
 *
 */
 
add_filter( 'genesis_seo_title', 'logo_filter_genesis_seo_site_title', 10, 2 );
 
function logo_filter_genesis_seo_site_title( $title, $inside ){
 
	$child_inside = sprintf( '<a href="%s"><img src="'. get_stylesheet_directory_uri() .'/images/cnmi-logo.svg" alt="%s"/></a>', trailingslashit( home_url() ), esc_attr( get_bloginfo( 'name' ) ), esc_attr( get_bloginfo( 'name' ) ), esc_attr( get_bloginfo( 'name' ) ) );
 
	$title = str_replace( $inside, $child_inside, $title );
 
	return $title;
	
}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
add_action( 'genesis_header_right', 'genesis_seo_site_title' );

// Add support for excerpts on pages
add_post_type_support( 'page', 'excerpt' );

// Unregister layout settings.
genesis_unregister_layout('content-sidebar-sidebar');
genesis_unregister_layout('sidebar-content-sidebar');
genesis_unregister_layout('sidebar-sidebar-content');

// Unregister secondary sidebar.
unregister_sidebar('sidebar-alt');
unregister_sidebar('sidebar');

// Remove the site description.
remove_action('genesis_site_description', 'genesis_seo_site_description');

// Rename menus.
add_theme_support('genesis-menus', array('primary' => __('After Header Menu', 'executive-pro'), 'secondary' => __('Footer Menu', 'executive-pro')));

// Remove output of primary navigation right extras.
remove_filter('genesis_nav_items', 'genesis_nav_right', 10, 2);
remove_filter('wp_nav_menu_items', 'genesis_nav_right', 10, 2);

// Remove navigation meta box.
add_action('genesis_theme_settings_metaboxes', 'executive_remove_genesis_metaboxes');
function executive_remove_genesis_metaboxes($_genesis_theme_settings_pagehook) {
	remove_meta_box('genesis-theme-settings-nav', $_genesis_theme_settings_pagehook, 'main');
}

// Reposition the secondary navigation menu.
remove_action('genesis_after_header', 'genesis_do_subnav');
add_action('genesis_footer', 'genesis_do_subnav', 7);

// Reduce the secondary navigation menu to one level depth.
add_filter('wp_nav_menu_args', 'executive_secondary_menu_args');
function executive_secondary_menu_args($args) {

	if('secondary' != $args['theme_location']) {
		return $args;
	}

	$args['depth'] = 1;

	return $args;

}

// Relocate the post info.
remove_action('genesis_entry_header', 'genesis_post_info', 12);
add_action('genesis_entry_header', 'genesis_post_info', 5);

// Add support for 3-column footer widgets.
add_theme_support('genesis-footer-widgets', 3);

// Register widget areas.
genesis_register_sidebar(array(
	'id' => 'home-slider',
	'name' => __('Home - Slider', 'executive-pro'),
	'description' => __('This is the slider section on the home page.', 'executive-pro'),
));

add_action('genesis_after', 'genesis_do_copyright');
function genesis_do_copyright() {
	echo '<p class="copyright">CNM Ingenuity, Inc. &copy;' . date("Y") . '. Website design and development by <a href="https://ingenuitysoftwarelabs.com">Ingenuity Software Labs, Inc.</a></p>';
}

remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );


//Adding add_action to change #of posts seen on archive page
add_action('pre_get_posts', 'be_change_event_posts_per_page');
/**
 * Change Posts Per Page for Program Archive
 *
 * @param object $query data
 *
 */
function be_change_event_posts_per_page($query) {

	if($query->is_main_query() && !is_admin() && is_post_type_archive('program')) {
		$query->set('posts_per_page', '30');
	}
}



//-------------------------------------------------------------------------------------------------------------


//This function adds 'tags' and 'categories' to Pages. WP default doesn't allow that, this does. Now when we create a new Page in the Dashboard, we have the option of giving it a Category, which is essential for our custom Category Functions

function add_taxonomies_to_pages() {
	register_taxonomy_for_object_type('post_tag', 'page');
	register_taxonomy_for_object_type('category', 'page');
}

add_action('init', 'add_taxonomies_to_pages');




//--------------------------------------------------------------------------------------------------------------

//This function pulls in the linked web fonts for use on the entire site

//* Enqueue Google fonts, Typography.com fonts, Font Awesome
add_action( 'wp_enqueue_scripts', 'cnmi_enqueue_stylesheets' );
function cnmi_enqueue_stylesheets() {
	wp_enqueue_style( 'google-font-roboto', '//fonts.googleapis.com/css?family=Roboto:300,400,900', array(), CHILD_THEME_VERSION );
	wp_enqueue_style('font-awesome', '//use.fontawesome.com/releases/v5.0.13/css/all.css');
	wp_enqueue_style('typography', '//cloud.typography.com/6861816/6338192/css/fonts.css');
}

//Registering CTA widget area
genesis_register_sidebar(array(
	'id' => 'partner-cta',
	'name' => __('Partnership Page - Call To Action', 'executive-pro'),
	'description' => __('This is the call to action section on the Partner page.', 'executive-pro'),
));

//Registering CTA widget area
genesis_register_sidebar(array(
	'id' => 'impact-cta',
	'name' => __('Impact Page - Call To Action', 'executive-pro'),
	'description' => __('This is the call to action section on the Impact page.', 'executive-pro'),
));

//Registering CTA widget area
genesis_register_sidebar(array(
	'id' => 'about-cta',
	'name' => __('About Page - Our Mission', 'executive-pro'),
	'description' => __('This is the "Our Mission" CTA section on the About page.', 'executive-pro'),
	'before_title' => '<h3 class="about-widget-title">',
	'after_title' => '</h3>',
));

// Use current_screen hook to alter the programs post type, category section
add_action( 'current_screen', 'program_cpt' );

function program_cpt() {
    $current_screen = get_current_screen();

    if ($current_screen->post_type == 'program' || strstr($_SERVER['REQUEST_URI'], 'program')) {
        ob_start('one_category_only');
    }
}

function one_category_only($content) {
    $content = str_replace('type="checkbox" name="post_category[]" ', 'type="radio" name="post_category[]" ', $content);
    return $content;
}

function the_excerpt_max_charlength($charlength) {
    $excerpt = get_the_excerpt();
    $charlength++;

    if ( mb_strlen( $excerpt ) > $charlength ) {
        $subex = mb_substr( $excerpt, 0, $charlength - 5 );
        $exwords = explode( ' ', $subex );
        $excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
        if ( $excut < 0 ) {
            return mb_substr( $subex, 0, $excut ) . '...';
        } else {
            return $subex . '...';
        }
    } else {
        return $excerpt . '...';
    }
}