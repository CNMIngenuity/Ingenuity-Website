<?php
	/**
	Plugin Name: CNMI Custom Post Type Plugin
	Plugin URI: https://github.com/IngenuitySoftwareLabs/cnmi-custom-post-types
	description: a plugin to create custom post types for CNM Ingenuity, Inc
	Version: 1.2
	Author: Ingenuity Software Labs
	Author URI: https://ingenuitysoftwarelabs.com/
	License: Apache License 2.0
	**/


// Our custom post type function
function custom_post_type() {

	//Program Post Type

	$progLabels = array(
		'name'                  => _x( 'Programs', 'cnmi' ),
		'singular_name'         => _x( 'Program', 'cnmi' ),
		'menu_name'             => __( 'Programs', 'cnmi' ),
		'name_admin_bar'        => __( 'Program', 'cnmi' ),
		'archives'              => __( 'Item Archives', 'cnmi' ),
		'attributes'            => __( 'Item Attributes', 'cnmi' ),
		'parent_item_colon'     => __( 'Parent Program:', 'cnmi' ),
		'all_items'             => __( 'All Programs', 'cnmi' ),
		'add_new_item'          => __( 'Add New Program', 'cnmi' ),
		'add_new'               => __( 'Add New', 'cnmi' ),
		'new_item'              => __( 'New Program', 'cnmi' ),
		'edit_item'             => __( 'Edit Program', 'cnmi' ),
		'update_item'           => __( 'Update Program', 'cnmi' ),
		'view_item'             => __( 'View Program', 'cnmi' ),
		'view_items'            => __( 'View Programs', 'cnmi' ),
		'search_items'          => __( 'Search Program', 'cnmi' ),
		'not_found'             => __( 'Not found', 'cnmi' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'cnmi' ),
		'featured_image'        => __( 'Featured Image', 'cnmi' ),
		'set_featured_image'    => __( 'Set featured image', 'cnmi' ),
		'remove_featured_image' => __( 'Remove featured image', 'cnmi' ),
		'use_featured_image'    => __( 'Use as featured image', 'cnmi' ),
		'insert_into_item'      => __( 'Insert into program', 'cnmi' ),
		'uploaded_to_this_item' => __( 'Uploaded to this program', 'cnmi' ),
		'items_list'            => __( 'Programs list', 'cnmi' ),
		'items_list_navigation' => __( 'Programs list navigation', 'cnmi' ),
		'filter_items_list'     => __( 'Filter programs list', 'cnmi' ),
	);
	$progArgs = array(
		'label'                 => __( 'Program', 'cnmi' ),
		'description'           => __( 'Programs, Brands, and Initiatives' ),
		'labels'                => $progLabels,
		'supports'              => array('title', 'editor', 'genesis-seo', 'thumbnail','genesis-cpt-archives-settings', 'excerpt', 'custom-fields', 'revisions'),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-images-alt',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'program', $progArgs );

	//Success Story Post Type

	$successLabels = array(
		'name'                  => _x( 'Success Stories', 'cnmi' ),
		'singular_name'         => _x( 'Success Story', 'cnmi' ),
		'menu_name'             => __( 'Success Stories', 'cnmi' ),
		'name_admin_bar'        => __( 'Success Story', 'cnmi' ),
		'archives'              => __( 'Item Archives', 'cnmi' ),
		'attributes'            => __( 'Item Attributes', 'cnmi' ),
		'parent_item_colon'     => __( 'Parent Success Story:', 'cnmi' ),
		'all_items'             => __( 'All Success Stories', 'cnmi' ),
		'add_new_item'          => __( 'Add New Success Story', 'cnmi' ),
		'add_new'               => __( 'Add New', 'cnmi' ),
		'new_item'              => __( 'New Success Story', 'cnmi' ),
		'edit_item'             => __( 'Edit Success Story', 'cnmi' ),
		'update_item'           => __( 'Update Success Story', 'cnmi' ),
		'view_item'             => __( 'View Success Story', 'cnmi' ),
		'view_items'            => __( 'View Success Storys', 'cnmi' ),
		'search_items'          => __( 'Search Success Story', 'cnmi' ),
		'not_found'             => __( 'Not found', 'cnmi' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'cnmi' ),
		'featured_image'        => __( 'Featured Image', 'cnmi' ),
		'set_featured_image'    => __( 'Set featured image', 'cnmi' ),
		'remove_featured_image' => __( 'Remove featured image', 'cnmi' ),
		'use_featured_image'    => __( 'Use as featured image', 'cnmi' ),
		'insert_into_item'      => __( 'Insert into success', 'cnmi' ),
		'uploaded_to_this_item' => __( 'Uploaded to this success story', 'cnmi' ),
		'items_list'            => __( 'Success Stories list', 'cnmi' ),
		'items_list_navigation' => __( 'Success Stories list navigation', 'cnmi' ),
		'filter_items_list'     => __( 'Filter Success Stories list', 'cnmi' ),
	);
	$successArgs = array(
		'label'                 => __( 'Success Story', 'cnmi' ),
		'description'           => __( 'Success Stories' ),
		'labels'                => $successLabels,
		'supports'              => array('title', 'editor', 'genesis-seo', 'thumbnail','genesis-cpt-archives-settings', 'excerpt', 'custom-fields', 'revisions'),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-media-document',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'success', $successArgs );

	//News Post Type

	$newsLabels = array(
		'name'                  => _x( 'News', 'cnmi' ),
		'singular_name'         => _x( 'News', 'cnmi' ),
		'menu_name'             => __( 'News', 'cnmi' ),
		'name_admin_bar'        => __( 'News', 'cnmi' ),
		'archives'              => __( 'Item Archives', 'cnmi' ),
		'attributes'            => __( 'Item Attributes', 'cnmi' ),
		'parent_item_colon'     => __( 'Parent News:', 'cnmi' ),
		'all_items'             => __( 'All News', 'cnmi' ),
		'add_new_item'          => __( 'Add New News', 'cnmi' ),
		'add_new'               => __( 'Add New', 'cnmi' ),
		'new_item'              => __( 'New News', 'cnmi' ),
		'edit_item'             => __( 'Edit News', 'cnmi' ),
		'update_item'           => __( 'Update News', 'cnmi' ),
		'view_item'             => __( 'View News', 'cnmi' ),
		'view_items'            => __( 'View News', 'cnmi' ),
		'search_items'          => __( 'Search News', 'cnmi' ),
		'not_found'             => __( 'Not found', 'cnmi' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'cnmi' ),
		'featured_image'        => __( 'Featured Image', 'cnmi' ),
		'set_featured_image'    => __( 'Set featured image', 'cnmi' ),
		'remove_featured_image' => __( 'Remove featured image', 'cnmi' ),
		'use_featured_image'    => __( 'Use as featured image', 'cnmi' ),
		'insert_into_item'      => __( 'Insert into news', 'cnmi' ),
		'uploaded_to_this_item' => __( 'Uploaded to this news', 'cnmi' ),
		'items_list'            => __( 'News list', 'cnmi' ),
		'items_list_navigation' => __( 'News list navigation', 'cnmi' ),
		'filter_items_list'     => __( 'Filter news list', 'cnmi' ),
	);
	$newsArgs = array(
		'label'                 => __( 'News', 'cnmi' ),
		'description'           => __( 'News, Articles, and related Media' ),
		'labels'                => $newsLabels,
		'supports'              => array('title', 'editor', 'genesis-seo', 'thumbnail','genesis-cpt-archives-settings', 'excerpt', 'custom-fields', 'revisions'),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-format-chat',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'news', $newsArgs );

	//Staff Post Type

	$staffLabels = array(
		'name'                  => _x( 'Staff', 'cnmi' ),
		'singular_name'         => _x( 'Staff', 'cnmi' ),
		'menu_name'             => __( 'Staff', 'cnmi' ),
		'name_admin_bar'        => __( 'Staff', 'cnmi' ),
		'archives'              => __( 'Item Archives', 'cnmi' ),
		'attributes'            => __( 'Item Attributes', 'cnmi' ),
		'parent_item_colon'     => __( 'Parent Staff:', 'cnmi' ),
		'all_items'             => __( 'All Staff', 'cnmi' ),
		'add_new_item'          => __( 'Add New Staff', 'cnmi' ),
		'add_new'               => __( 'Add Staff', 'cnmi' ),
		'new_item'              => __( 'New Staff', 'cnmi' ),
		'edit_item'             => __( 'Edit Staff', 'cnmi' ),
		'update_item'           => __( 'Update Staff', 'cnmi' ),
		'view_item'             => __( 'View Staff', 'cnmi' ),
		'view_items'            => __( 'View Staff', 'cnmi' ),
		'search_items'          => __( 'Search Staff', 'cnmi' ),
		'not_found'             => __( 'Not found', 'cnmi' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'cnmi' ),
		'featured_image'        => __( 'Featured Image', 'cnmi' ),
		'set_featured_image'    => __( 'Set featured image', 'cnmi' ),
		'remove_featured_image' => __( 'Remove featured image', 'cnmi' ),
		'use_featured_image'    => __( 'Use as featured image', 'cnmi' ),
		'insert_into_item'      => __( 'Insert into staff', 'cnmi' ),
		'uploaded_to_this_item' => __( 'Uploaded to this staff', 'cnmi' ),
		'items_list'            => __( 'Staff list', 'cnmi' ),
		'items_list_navigation' => __( 'Staff list navigation', 'cnmi' ),
		'filter_items_list'     => __( 'Filter staff list', 'cnmi' ),
	);
	$staffArgs = array(
		'label'                 => __( 'News', 'cnmi' ),
		'description'           => __( 'News, Articles, and related Media' ),
		'labels'                => $staffLabels,
		'supports'              => array('title', 'editor', 'genesis-seo', 'thumbnail','genesis-cpt-archives-settings', 'excerpt', 'custom-fields', 'revisions'),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-groups',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'staff', $staffArgs );

}
add_action( 'init', 'custom_post_type', 0 );